#! /bin/bash

HOST="localhost"
HOMEDIR=`dirname $0`

ABSDIR="$(cd "$(dirname "$0")" && pwd)"
# Replace @TEAMDIR@ with the actual team directory in the configuration files
# ./bin/oxsysoccr.conf.tmpl
sed "s|@TEAMDIR@|${ABSDIR}|g" ${ABSDIR}/bin/oxsysoccer.conf.tmpl > ${ABSDIR}/bin/oxsysoccer.conf

# ./strategy/oxsystrategy.conf.tmpl
sed "s|@TEAMDIR@|${ABSDIR}|g" ${ABSDIR}/strategy/oxsystrategy.conf.tmpl > ${ABSDIR}/strategy/oxsystrategy.conf


${HOMEDIR}/start ${HOST} ${HOMEDIR} 1 &
sleep 1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 2 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 3 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 4 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 5 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 6 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 7 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 8 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 9 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 10 &
sleep 0.1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 11 &
sleep 1
${HOMEDIR}/start ${HOST} ${HOMEDIR} 12 &


sleep 1
rm -f ${ABSDIR}/bin/oxsysoccer.conf
rm -f ${ABSDIR}/strategy/oxsystrategy.conf
